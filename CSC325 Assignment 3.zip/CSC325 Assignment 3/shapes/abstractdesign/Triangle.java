package shapes.abstractdesign;

// Triangle class extending Shape and using only the abstract class's methods
public class Triangle extends Shape {
    final private String color;
    final private String name;
    final private double base;
    final private double height;

    // Constructor
    public Triangle(String color, String name, double base, double height) {
        this.color = color;
        this.name = name;
        this.base = base;
        this.height = height;
    }
    
    // Abstract methods overridden and given functionality
    @Override
    public String getColor() {
        return color;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getArea() {
        return 0.5 * base * height;
    }

    @Override
    public void draw() {
        System.out.println("Drawing a " + color + " " + name + " with base " + base + " and height " + height);
    }
}