package shapes.abstractdesign;

// Rectangle class extending Shape and using only the abstract class's methods
public class Rectangle extends Shape {
    final private String color;
    final private String name;
    final private double length;
    final private double width;

    // Constructor
    public Rectangle(String color, String name, double length, double width) {
        this.color = color;
        this.name = name;
        this.length = length;
        this.width = width;
    }

    // Abstract methods overridden and given functionality
    @Override
    public String getColor() {
        return color;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getArea() {
        return length * width;
    }

    @Override
    public void draw() {
        System.out.println("Drawing a " + color + " " + name + " with length " + length + " and width " + width);
    }
}
