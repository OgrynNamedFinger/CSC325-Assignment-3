package shapes.abstractdesign;

public class Trapezoid extends Shape {
    final private String color;
    final private String name;
    final private double base1;
    final private double base2;
    final private double height;

    // Constructor
    public Trapezoid(String color, String name, double base1, double base2, double height) {
        this.color = color;
        this.name = name;
        this.base1 = base1;
        this.base2 = base2;
        this.height = height;
    }

    // Abstract methods overridden and given functionality
    @Override
    public String getColor() {
        return color;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getArea() {
        return 0.5 * (base1 + base2) * height;
    }

    @Override
    public void draw() {
        System.out.println("Drawing a " + color + " " + name + " with bases " + base1 + ", " + base2 + " and height " + height);
    }
    
}
