package shapes.abstractdesign;

// Abstract class Shape
public abstract class Shape {
    private String color;
    private String name;
    private double length;
    private double width;

    // Abstract methods to be implemented by subclasses
    public abstract String getColor();
    public abstract String getName();
    public abstract double getArea();
    public abstract void draw();
}