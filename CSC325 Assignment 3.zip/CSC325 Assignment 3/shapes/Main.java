package shapes;
// Package into shapes folder

// Import necessary classes and packages
import java.util.Scanner;
import shapes.abstractdesign.*;

public class Main {
    public static void main(String[] args) {
        // Create instances of shapes, both abstract class and interface implementations
        Shape rectangle = new Rectangle("Blue", "Rectangle", 4.0, 6.0);
        Shape triangle = new Triangle("Green", "Triangle", 3.0, 4.0);
        Shape trapezoid = new Trapezoid("Orange", "Trapezoid", 3.0, 5.0, 4.0);
        shapes.interfacedesign.Octagon octagon = new shapes.interfacedesign.Octagon("Red", "Octagon", 2.0);
        shapes.interfacedesign.Pentagon pentagon = new shapes.interfacedesign.Pentagon("Yellow", "Pentagon", 3.0);
        shapes.interfacedesign.Hexagon hexagon = new shapes.interfacedesign.Hexagon("Purple", "Hexagon", 2.5);

        // Initialize scanner for user input
        Scanner scanner = new Scanner(System.in);
        
        // Menu-driven interface
        boolean exit = false;
        while (!exit) {
            while (!exit) {
            System.out.println("Menu:");
            System.out.println("1. Call methods from shapes using abstract class");
            System.out.println("2. Call methods from shapes using interfaces");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            //Switch case for menu options
            switch (choice) {
                case 1 -> {
                    // Call methods for shapes using abstract class
                    rectangle.draw();
                    System.out.println("Area of " + rectangle.getName() + ": " + rectangle.getArea());
                    triangle.draw();
                    System.out.println("Area of " + triangle.getName() + ": " + triangle.getArea());
                    trapezoid.draw();
                    System.out.println("Area of " + trapezoid.getName() + ": " + trapezoid.getArea());
                    }

                    // Call methods for shapes using interfaces
                    case 2 -> {
                        octagon.draw();
                        System.out.println("Area of " + octagon.getName() + ": " + octagon.getArea());
                        System.out.println(octagon.getDescription());
                        pentagon.draw();
                        System.out.println("Area of " + pentagon.getName() + ": " + pentagon.getArea());
                        System.out.println(pentagon.getDescription());
                        hexagon.draw();
                        System.out.println("Area of " + hexagon.getName() + ": " + hexagon.getArea());
                        System.out.println(hexagon.getDescription());
                    }

                    // Exit the program
                    case 3 -> exit = true;
                
                // Handle invalid input/exception catching
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
        // close scanner
        scanner.close();
    }
}
}
