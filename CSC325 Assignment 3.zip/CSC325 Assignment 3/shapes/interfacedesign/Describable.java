package shapes.interfacedesign;

// Interface for shapes that can provide a description
public interface Describable {
    String getDescription();
}
