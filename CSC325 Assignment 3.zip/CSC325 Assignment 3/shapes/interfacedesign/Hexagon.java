package shapes.interfacedesign;

// Hexagon class implementing multiple interfaces
public class Hexagon implements Calculable, Drawable, Describable {
    final private String color;
    final private String name;
    final private double side;

    // Constructor method
    public Hexagon(String color, String name, double side) {
        this.color = color;
        this.name = name;
        this.side = side;
    }

    // Implementing interface methods and giving them functionality
    @Override
    public double getArea() {
        return (3 * Math.sqrt(3) / 2) * side * side;
    }

    @Override
    public void draw() {
        System.out.println("Drawing a " + color + " " + name + " with a side length of " + side);
    }

    @Override
    public String getDescription() {
        return "This is a " + color + " " + name + " with an area of " + getArea();
    }

    public String getColor() {
        return color;
    }
    
    public String getName() {
        return name;
    }
    
}
