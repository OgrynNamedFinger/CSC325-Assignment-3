package shapes.interfacedesign;

// Pentagon class implementing multiple interfaces and extending Shape; meant to demonstrate polymorphism
public class Pentagon implements Calculable, Drawable, Describable {
    final private String color;
    final private String name;
    final private double side;

    public Pentagon(String color, String name, double side) {
        this.color = color;
        this.name = name;
        this.side = side;
    }

    // Implementing interface methods and giving them functionality
    @Override
    public double getArea() {
        return (1/4.0) * Math.sqrt(5 * (5 + 2 * Math.sqrt(5))) * side * side;
    }

    @Override
    public void draw() {
        System.out.println("Drawing a " + color + " " + name + " with a side length of " + side);
    }

    @Override
    public String getDescription() {
        return "This is a " + color + " " + name + " with an area of " + getArea();
    }

    public String getColor() {
        return color;
    }

    public String getName() {  
        return name;
    }
    
}
