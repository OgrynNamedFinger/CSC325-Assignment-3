package shapes.interfacedesign;

// Interface for shapes that can be drawn
public interface Drawable {
    void draw();
}
