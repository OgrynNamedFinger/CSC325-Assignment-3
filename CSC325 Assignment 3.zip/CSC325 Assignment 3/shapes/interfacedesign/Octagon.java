package shapes.interfacedesign;

// Octagon class implementing multiple interfaces
public class Octagon implements Calculable, Drawable, Describable {
    final private String color;
    final private String name;
    final private double side;

    // Constructor method
    public Octagon(String color, String name, double side) {
        this.color = color;
        this.name = name;
        this.side = side;
    }
    
    // Implementing interface methods and giving them functionality
    @Override
    public double getArea() {
        return 2 * (1 + Math.sqrt(2)) * side * side;
    }

    @Override
    public void draw() {
        System.out.println("Drawing a " + color + " " + name + " with a side length of " + side);
    }

    @Override
    public String getDescription() {
        return "This is a " + color + " " + name + " with an area of " + getArea();
    }

    public String getColor() {
        return color;
    }
    
    public String getName() {
        return name;
    }
}
