package shapes.interfacedesign;

// Interface for shapes that can calculate their area
public interface Calculable {
    double getArea();
}
